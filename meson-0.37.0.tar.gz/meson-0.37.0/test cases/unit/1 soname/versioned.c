int versioned_func() {
    return 0;
}
