#ifdef _MSC_VER
int somedllfunc() {
    return 42;
}
#endif
