package com.mesonbuild;

class Simple {
    public static void main(String [] args) {
        System.out.println("Java is working.\n");
    }
}
