int sub_lib_method() {
    return 1337;
}
