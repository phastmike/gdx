int func() {
    return 5;
}
