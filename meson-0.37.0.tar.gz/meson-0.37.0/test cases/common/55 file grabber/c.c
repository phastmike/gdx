int funcc() { return 0; }
