int funca() { return 0; }
