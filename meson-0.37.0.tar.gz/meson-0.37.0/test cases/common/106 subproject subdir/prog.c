#include <sub.h>

int main() {
	return sub();
}
