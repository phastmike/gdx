#!/usr/bin/env python

import os
import sys

with open(sys.argv[1], 'w') as f:
    f.write('')
