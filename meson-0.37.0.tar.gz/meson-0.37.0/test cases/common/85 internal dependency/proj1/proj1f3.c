#include<proj1.h>
#include<stdio.h>

void proj1_func3() {
    printf("In proj1_func3.\n");
}
