int func1_in_obj();
int func2_in_obj();
int func3_in_obj();

int main(int argc, char **argv) {
    return func1_in_obj() + func2_in_obj() + func3_in_obj();
}
