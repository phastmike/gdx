int first(void);

int main() {
	return first() - 1001;
}
