extern "C" int func();

class BreakPlainCCompiler;

int main(int argc, char **argv) {
    return func();
}
