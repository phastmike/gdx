#include"generated.h"

int main(int argc, char **argv) {
    return THE_NUMBER != 9 || THE_ARG1 != 5 || THE_ARG2 != 33;
}
