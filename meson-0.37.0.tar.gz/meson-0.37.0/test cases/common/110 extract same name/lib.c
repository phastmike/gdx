int func1() {
    return 23;
}
