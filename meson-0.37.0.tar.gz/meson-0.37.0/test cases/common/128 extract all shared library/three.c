#include"extractor.h"

int func3() {
    return 3;
}
