#include<stdio.h>

int main(int argc, char **argv) {
    printf("I am test exe2.\n");
    return 0;
}
