int statlibfunc();

int main(int argc, char **argv) {
    return statlibfunc();
}
