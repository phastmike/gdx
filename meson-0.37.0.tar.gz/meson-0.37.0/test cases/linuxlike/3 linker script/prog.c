#include"bob.h"

int main(int argc, char **argv) {
    return bobMcBob() != 42;
}
