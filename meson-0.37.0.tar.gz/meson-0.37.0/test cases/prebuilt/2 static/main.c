#include<stdio.h>
#include<best.h>

int main(int argc, char **argv) {
    printf("%s\n", msg());
    return 0;
}
