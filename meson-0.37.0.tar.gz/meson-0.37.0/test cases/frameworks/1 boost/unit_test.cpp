#define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MODULE "MesonTest"
#define BOOST_TEST_MAIN
#include <boost/test/unit_test.hpp>

BOOST_AUTO_TEST_CASE(m_test) {
    int x = 2+2;
    BOOST_CHECK(true);
    BOOST_CHECK_EQUAL(x, 4);
}
