#include "meson-subsample.h"

gint
main (gint   argc,
      gchar *argv[])
{
  MesonSample * i = (MesonSample*) meson_sub_sample_new ("Hello, sub/meson/c!");
  meson_sample_print_message (i);
  g_object_unref (i);

  return 0;
}
