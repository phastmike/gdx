#!/usr/bin/env python3
from gi.repository import Meson, MesonDep1, MesonDep2

if __name__ == "__main__":
    s = Meson.Sample.new()
    dep1 = MesonDep1.Dep1.new()
    dep2 = MesonDep2.Dep2.new("Hello, meson/py!")
    s.print_message(dep1, dep2)
