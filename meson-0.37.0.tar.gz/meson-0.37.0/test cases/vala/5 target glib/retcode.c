int
get_ret_code (void)
{
  return 42;
}
