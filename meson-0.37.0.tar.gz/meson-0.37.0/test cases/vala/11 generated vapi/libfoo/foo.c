#include "foo.h"

/**
 * foo_return_success:
 *
 * Returns 0
 */
int foo_return_success(void)
{
	return 0;
}
