int retval (void);

int test (void) {
    return retval ();
}
